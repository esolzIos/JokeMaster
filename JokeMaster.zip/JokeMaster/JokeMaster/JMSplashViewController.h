//
//  JMSplashViewController.h
//  JokeMaster
//
//  Created by santanu on 02/06/17.
//  Copyright © 2017 esolz. All rights reserved.
//

#import "JMGlobalMethods.h"

@interface JMSplashViewController : JMGlobalMethods

@end
